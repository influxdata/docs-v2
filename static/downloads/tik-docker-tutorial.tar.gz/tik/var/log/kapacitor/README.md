This directory should remain empty except for this file.  This directory is
mapped into the Kapacitor container as a volume, so that it is easier to access
and monitor log files. 
